/*
 * ipv4_lib.h
 *
 *  Created on: Oct 23, 2017
 *      Author: konrad
 */

#ifndef IPV4_LIB_H_
#define IPV4_LIB_H_

#include <netinet/ip.h>


unsigned short * CreateIpv4Packet ();




#endif /* IPV4_LIB_H_ */
