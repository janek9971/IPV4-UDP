#ifndef ICMP_LIB_H_
#define ICMP_LIB_H_

void UdpPacket ( unsigned char * datagram );

#endif /* ICMP_LIB_H_ */
